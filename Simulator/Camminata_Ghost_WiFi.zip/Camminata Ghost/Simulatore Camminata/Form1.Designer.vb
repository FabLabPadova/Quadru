﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.picFianco = New System.Windows.Forms.PictureBox()
        Me.picSopra = New System.Windows.Forms.PictureBox()
        Me.tmrCamminata = New System.Windows.Forms.Timer(Me.components)
        Me.trkVelAlzo = New System.Windows.Forms.TrackBar()
        Me.trkPasso = New System.Windows.Forms.TrackBar()
        Me.lblVelocita = New System.Windows.Forms.Label()
        Me.lblPasso = New System.Windows.Forms.Label()
        Me.trkSpinta = New System.Windows.Forms.TrackBar()
        Me.lblSpinta = New System.Windows.Forms.Label()
        Me.btnstart = New System.Windows.Forms.Button()
        Me.trkLunghezza = New System.Windows.Forms.TrackBar()
        Me.trkLarghezza = New System.Windows.Forms.TrackBar()
        Me.lblLunghezza = New System.Windows.Forms.Label()
        Me.lblLarghezza = New System.Windows.Forms.Label()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.trkFermore = New System.Windows.Forms.TrackBar()
        Me.lblRapporto = New System.Windows.Forms.Label()
        Me.btnFianco = New System.Windows.Forms.Button()
        Me.btnSopra = New System.Windows.Forms.Button()
        Me.btnBaricentro = New System.Windows.Forms.Button()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.trkTimer = New System.Windows.Forms.TrackBar()
        Me.lblTimer = New System.Windows.Forms.Label()
        Me.trkRitardoAlzo = New System.Windows.Forms.TrackBar()
        Me.lblRitardoAlzo = New System.Windows.Forms.Label()
        Me.lblGamba = New System.Windows.Forms.Label()
        Me.lblDiscriminante = New System.Windows.Forms.Label()
        Me.txtGamba = New System.Windows.Forms.TextBox()
        Me.txtDiscriminante = New System.Windows.Forms.TextBox()
        Me.btnBaricentro1 = New System.Windows.Forms.Button()
        Me.chkForma = New System.Windows.Forms.CheckBox()
        Me.trkCurva = New System.Windows.Forms.TrackBar()
        Me.lblCurva = New System.Windows.Forms.Label()
        Me.trktibia = New System.Windows.Forms.TrackBar()
        Me.lblTibia = New System.Windows.Forms.Label()
        Me.lblCoppia = New System.Windows.Forms.Label()
        Me.txtCoppia = New System.Windows.Forms.TextBox()
        Me.lblPeso = New System.Windows.Forms.Label()
        Me.txtPeso = New System.Windows.Forms.TextBox()
        Me.lblCom = New System.Windows.Forms.Label()
        Me.txtCom = New System.Windows.Forms.TextBox()
        Me.btnAttenti = New System.Windows.Forms.Button()
        Me.chkTestGamba = New System.Windows.Forms.CheckBox()
        Me.lblServo = New System.Windows.Forms.Label()
        Me.lblAngolo = New System.Windows.Forms.Label()
        Me.txtAngoloExt = New System.Windows.Forms.TextBox()
        Me.txtTestGamba = New System.Windows.Forms.TextBox()
        Me.lstTestServo = New System.Windows.Forms.ListBox()
        Me.trkMarcia = New System.Windows.Forms.TrackBar()
        Me.lblMarcia = New System.Windows.Forms.Label()
        Me.chkRetro = New System.Windows.Forms.CheckBox()
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.txtAngoloInt = New System.Windows.Forms.TextBox()
        Me.txtRotazione = New System.Windows.Forms.TextBox()
        Me.lblExt = New System.Windows.Forms.Label()
        Me.lblInt = New System.Windows.Forms.Label()
        Me.lblRot = New System.Windows.Forms.Label()
        Me.TrkTibiaInt = New System.Windows.Forms.TrackBar()
        Me.lblTibiaInt = New System.Windows.Forms.Label()
        Me.txtValExt = New System.Windows.Forms.TextBox()
        Me.txtValInt = New System.Windows.Forms.TextBox()
        CType(Me.picFianco, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picSopra, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkVelAlzo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkPasso, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkSpinta, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkLunghezza, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkLarghezza, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkFermore, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkTimer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkRitardoAlzo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkCurva, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trktibia, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkMarcia, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrkTibiaInt, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'picFianco
        '
        Me.picFianco.BackColor = System.Drawing.SystemColors.ControlLight
        Me.picFianco.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.picFianco.Location = New System.Drawing.Point(28, 22)
        Me.picFianco.Name = "picFianco"
        Me.picFianco.Size = New System.Drawing.Size(290, 130)
        Me.picFianco.TabIndex = 0
        Me.picFianco.TabStop = False
        '
        'picSopra
        '
        Me.picSopra.BackColor = System.Drawing.SystemColors.ControlLight
        Me.picSopra.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.picSopra.Location = New System.Drawing.Point(28, 198)
        Me.picSopra.Name = "picSopra"
        Me.picSopra.Size = New System.Drawing.Size(305, 113)
        Me.picSopra.TabIndex = 1
        Me.picSopra.TabStop = False
        '
        'tmrCamminata
        '
        Me.tmrCamminata.Interval = 1000
        '
        'trkVelAlzo
        '
        Me.trkVelAlzo.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.trkVelAlzo.Location = New System.Drawing.Point(648, 75)
        Me.trkVelAlzo.Maximum = 20
        Me.trkVelAlzo.Name = "trkVelAlzo"
        Me.trkVelAlzo.Size = New System.Drawing.Size(162, 56)
        Me.trkVelAlzo.TabIndex = 2
        Me.trkVelAlzo.Value = 3
        '
        'trkPasso
        '
        Me.trkPasso.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.trkPasso.Location = New System.Drawing.Point(651, 198)
        Me.trkPasso.Maximum = 179
        Me.trkPasso.Name = "trkPasso"
        Me.trkPasso.Size = New System.Drawing.Size(162, 56)
        Me.trkPasso.TabIndex = 3
        Me.trkPasso.Value = 70
        '
        'lblVelocita
        '
        Me.lblVelocita.AutoSize = True
        Me.lblVelocita.Location = New System.Drawing.Point(816, 75)
        Me.lblVelocita.Name = "lblVelocita"
        Me.lblVelocita.Size = New System.Drawing.Size(91, 17)
        Me.lblVelocita.TabIndex = 4
        Me.lblVelocita.Text = "Velocita' alzo"
        '
        'lblPasso
        '
        Me.lblPasso.AutoSize = True
        Me.lblPasso.Location = New System.Drawing.Point(819, 198)
        Me.lblPasso.Name = "lblPasso"
        Me.lblPasso.Size = New System.Drawing.Size(47, 17)
        Me.lblPasso.TabIndex = 5
        Me.lblPasso.Text = "Passo"
        '
        'trkSpinta
        '
        Me.trkSpinta.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.trkSpinta.Location = New System.Drawing.Point(651, 137)
        Me.trkSpinta.Maximum = 200
        Me.trkSpinta.Name = "trkSpinta"
        Me.trkSpinta.Size = New System.Drawing.Size(162, 56)
        Me.trkSpinta.TabIndex = 6
        Me.trkSpinta.Value = 30
        '
        'lblSpinta
        '
        Me.lblSpinta.AutoSize = True
        Me.lblSpinta.Location = New System.Drawing.Point(819, 137)
        Me.lblSpinta.Name = "lblSpinta"
        Me.lblSpinta.Size = New System.Drawing.Size(85, 17)
        Me.lblSpinta.TabIndex = 7
        Me.lblSpinta.Text = "Veloc spinta"
        '
        'btnstart
        '
        Me.btnstart.Location = New System.Drawing.Point(648, 22)
        Me.btnstart.Name = "btnstart"
        Me.btnstart.Size = New System.Drawing.Size(71, 34)
        Me.btnstart.TabIndex = 8
        Me.btnstart.Text = "Start"
        Me.btnstart.UseVisualStyleBackColor = True
        '
        'trkLunghezza
        '
        Me.trkLunghezza.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.trkLunghezza.Location = New System.Drawing.Point(648, 261)
        Me.trkLunghezza.Maximum = 800
        Me.trkLunghezza.Name = "trkLunghezza"
        Me.trkLunghezza.Size = New System.Drawing.Size(162, 56)
        Me.trkLunghezza.TabIndex = 9
        Me.trkLunghezza.Value = 640
        '
        'trkLarghezza
        '
        Me.trkLarghezza.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.trkLarghezza.Location = New System.Drawing.Point(648, 323)
        Me.trkLarghezza.Maximum = 800
        Me.trkLarghezza.Name = "trkLarghezza"
        Me.trkLarghezza.Size = New System.Drawing.Size(162, 56)
        Me.trkLarghezza.TabIndex = 10
        Me.trkLarghezza.Value = 240
        '
        'lblLunghezza
        '
        Me.lblLunghezza.AutoSize = True
        Me.lblLunghezza.Location = New System.Drawing.Point(816, 261)
        Me.lblLunghezza.Name = "lblLunghezza"
        Me.lblLunghezza.Size = New System.Drawing.Size(78, 17)
        Me.lblLunghezza.TabIndex = 11
        Me.lblLunghezza.Text = "Lunghezza"
        '
        'lblLarghezza
        '
        Me.lblLarghezza.AutoSize = True
        Me.lblLarghezza.Location = New System.Drawing.Point(816, 323)
        Me.lblLarghezza.Name = "lblLarghezza"
        Me.lblLarghezza.Size = New System.Drawing.Size(75, 17)
        Me.lblLarghezza.TabIndex = 12
        Me.lblLarghezza.Text = "Larghezza"
        '
        'btnReset
        '
        Me.btnReset.Location = New System.Drawing.Point(725, 22)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(74, 34)
        Me.btnReset.TabIndex = 13
        Me.btnReset.Text = "Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'trkFermore
        '
        Me.trkFermore.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.trkFermore.Location = New System.Drawing.Point(648, 385)
        Me.trkFermore.Maximum = 500
        Me.trkFermore.Name = "trkFermore"
        Me.trkFermore.Size = New System.Drawing.Size(162, 56)
        Me.trkFermore.TabIndex = 14
        Me.trkFermore.Value = 130
        '
        'lblRapporto
        '
        Me.lblRapporto.AutoSize = True
        Me.lblRapporto.Location = New System.Drawing.Point(816, 385)
        Me.lblRapporto.Name = "lblRapporto"
        Me.lblRapporto.Size = New System.Drawing.Size(100, 17)
        Me.lblRapporto.TabIndex = 15
        Me.lblRapporto.Text = "Lungh Femore"
        '
        'btnFianco
        '
        Me.btnFianco.Location = New System.Drawing.Point(54, 34)
        Me.btnFianco.Name = "btnFianco"
        Me.btnFianco.Size = New System.Drawing.Size(249, 13)
        Me.btnFianco.TabIndex = 16
        Me.btnFianco.UseVisualStyleBackColor = True
        '
        'btnSopra
        '
        Me.btnSopra.Location = New System.Drawing.Point(37, 224)
        Me.btnSopra.Name = "btnSopra"
        Me.btnSopra.Size = New System.Drawing.Size(266, 31)
        Me.btnSopra.TabIndex = 17
        Me.btnSopra.UseVisualStyleBackColor = True
        '
        'btnBaricentro
        '
        Me.btnBaricentro.Location = New System.Drawing.Point(497, 223)
        Me.btnBaricentro.Name = "btnBaricentro"
        Me.btnBaricentro.Size = New System.Drawing.Size(5, 5)
        Me.btnBaricentro.TabIndex = 18
        Me.btnBaricentro.UseVisualStyleBackColor = True
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 50
        '
        'trkTimer
        '
        Me.trkTimer.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.trkTimer.Location = New System.Drawing.Point(395, 159)
        Me.trkTimer.Maximum = 2000
        Me.trkTimer.Name = "trkTimer"
        Me.trkTimer.Size = New System.Drawing.Size(162, 56)
        Me.trkTimer.TabIndex = 19
        Me.trkTimer.Value = 1000
        '
        'lblTimer
        '
        Me.lblTimer.AutoSize = True
        Me.lblTimer.Location = New System.Drawing.Point(415, 216)
        Me.lblTimer.Name = "lblTimer"
        Me.lblTimer.Size = New System.Drawing.Size(44, 17)
        Me.lblTimer.TabIndex = 20
        Me.lblTimer.Text = "Timer"
        '
        'trkRitardoAlzo
        '
        Me.trkRitardoAlzo.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.trkRitardoAlzo.Location = New System.Drawing.Point(395, 75)
        Me.trkRitardoAlzo.Maximum = 500
        Me.trkRitardoAlzo.Name = "trkRitardoAlzo"
        Me.trkRitardoAlzo.Size = New System.Drawing.Size(162, 56)
        Me.trkRitardoAlzo.TabIndex = 21
        '
        'lblRitardoAlzo
        '
        Me.lblRitardoAlzo.AutoSize = True
        Me.lblRitardoAlzo.Location = New System.Drawing.Point(563, 99)
        Me.lblRitardoAlzo.Name = "lblRitardoAlzo"
        Me.lblRitardoAlzo.Size = New System.Drawing.Size(97, 17)
        Me.lblRitardoAlzo.TabIndex = 22
        Me.lblRitardoAlzo.Text = "Ritardo Alzata"
        '
        'lblGamba
        '
        Me.lblGamba.AutoSize = True
        Me.lblGamba.Location = New System.Drawing.Point(816, 29)
        Me.lblGamba.Name = "lblGamba"
        Me.lblGamba.Size = New System.Drawing.Size(58, 17)
        Me.lblGamba.TabIndex = 23
        Me.lblGamba.Text = "Gamba:"
        '
        'lblDiscriminante
        '
        Me.lblDiscriminante.AutoSize = True
        Me.lblDiscriminante.Location = New System.Drawing.Point(884, 29)
        Me.lblDiscriminante.Name = "lblDiscriminante"
        Me.lblDiscriminante.Size = New System.Drawing.Size(58, 17)
        Me.lblDiscriminante.TabIndex = 24
        Me.lblDiscriminante.Text = "Discrim:"
        '
        'txtGamba
        '
        Me.txtGamba.Location = New System.Drawing.Point(465, 261)
        Me.txtGamba.Name = "txtGamba"
        Me.txtGamba.Size = New System.Drawing.Size(21, 22)
        Me.txtGamba.TabIndex = 25
        '
        'txtDiscriminante
        '
        Me.txtDiscriminante.Location = New System.Drawing.Point(395, 261)
        Me.txtDiscriminante.Name = "txtDiscriminante"
        Me.txtDiscriminante.Size = New System.Drawing.Size(51, 22)
        Me.txtDiscriminante.TabIndex = 26
        '
        'btnBaricentro1
        '
        Me.btnBaricentro1.Location = New System.Drawing.Point(525, 223)
        Me.btnBaricentro1.Name = "btnBaricentro1"
        Me.btnBaricentro1.Size = New System.Drawing.Size(5, 5)
        Me.btnBaricentro1.TabIndex = 27
        Me.btnBaricentro1.UseVisualStyleBackColor = True
        '
        'chkForma
        '
        Me.chkForma.AutoSize = True
        Me.chkForma.Checked = True
        Me.chkForma.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkForma.Location = New System.Drawing.Point(408, 28)
        Me.chkForma.Name = "chkForma"
        Me.chkForma.Size = New System.Drawing.Size(74, 21)
        Me.chkForma.TabIndex = 28
        Me.chkForma.Text = "Forma "
        Me.chkForma.UseVisualStyleBackColor = True
        '
        'trkCurva
        '
        Me.trkCurva.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.trkCurva.Location = New System.Drawing.Point(395, 302)
        Me.trkCurva.Maximum = 360
        Me.trkCurva.Name = "trkCurva"
        Me.trkCurva.Size = New System.Drawing.Size(162, 56)
        Me.trkCurva.TabIndex = 29
        Me.trkCurva.Value = 180
        '
        'lblCurva
        '
        Me.lblCurva.AutoSize = True
        Me.lblCurva.Location = New System.Drawing.Point(479, 323)
        Me.lblCurva.Name = "lblCurva"
        Me.lblCurva.Size = New System.Drawing.Size(198, 17)
        Me.lblCurva.TabIndex = 30
        Me.lblCurva.Text = "Curvatura                                "
        '
        'trktibia
        '
        Me.trktibia.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.trktibia.Location = New System.Drawing.Point(395, 364)
        Me.trktibia.Maximum = 500
        Me.trktibia.Name = "trktibia"
        Me.trktibia.Size = New System.Drawing.Size(162, 56)
        Me.trktibia.TabIndex = 31
        Me.trktibia.Value = 385
        '
        'lblTibia
        '
        Me.lblTibia.AutoSize = True
        Me.lblTibia.Location = New System.Drawing.Point(548, 382)
        Me.lblTibia.Name = "lblTibia"
        Me.lblTibia.Size = New System.Drawing.Size(83, 17)
        Me.lblTibia.TabIndex = 32
        Me.lblTibia.Text = "Lungh Tibia"
        '
        'lblCoppia
        '
        Me.lblCoppia.AutoSize = True
        Me.lblCoppia.Location = New System.Drawing.Point(995, 32)
        Me.lblCoppia.Name = "lblCoppia"
        Me.lblCoppia.Size = New System.Drawing.Size(113, 17)
        Me.lblCoppia.TabIndex = 33
        Me.lblCoppia.Text = "Coppia richiesta:"
        '
        'txtCoppia
        '
        Me.txtCoppia.Location = New System.Drawing.Point(506, 261)
        Me.txtCoppia.Name = "txtCoppia"
        Me.txtCoppia.Size = New System.Drawing.Size(36, 22)
        Me.txtCoppia.TabIndex = 34
        '
        'lblPeso
        '
        Me.lblPeso.AutoSize = True
        Me.lblPeso.Location = New System.Drawing.Point(948, 39)
        Me.lblPeso.Name = "lblPeso"
        Me.lblPeso.Size = New System.Drawing.Size(25, 17)
        Me.lblPeso.TabIndex = 35
        Me.lblPeso.Text = "gr:"
        '
        'txtPeso
        '
        Me.txtPeso.Location = New System.Drawing.Point(566, 261)
        Me.txtPeso.Name = "txtPeso"
        Me.txtPeso.Size = New System.Drawing.Size(34, 22)
        Me.txtPeso.TabIndex = 36
        Me.txtPeso.Text = "3000"
        '
        'lblCom
        '
        Me.lblCom.AutoSize = True
        Me.lblCom.Location = New System.Drawing.Point(948, 89)
        Me.lblCom.Name = "lblCom"
        Me.lblCom.Size = New System.Drawing.Size(34, 17)
        Me.lblCom.TabIndex = 37
        Me.lblCom.Text = "com"
        '
        'txtCom
        '
        Me.txtCom.Location = New System.Drawing.Point(610, 256)
        Me.txtCom.Name = "txtCom"
        Me.txtCom.Size = New System.Drawing.Size(21, 22)
        Me.txtCom.TabIndex = 38
        Me.txtCom.Text = "0"
        '
        'btnAttenti
        '
        Me.btnAttenti.Location = New System.Drawing.Point(1034, 72)
        Me.btnAttenti.Name = "btnAttenti"
        Me.btnAttenti.Size = New System.Drawing.Size(74, 34)
        Me.btnAttenti.TabIndex = 39
        Me.btnAttenti.Text = "Attenti!"
        Me.btnAttenti.UseVisualStyleBackColor = True
        '
        'chkTestGamba
        '
        Me.chkTestGamba.AutoSize = True
        Me.chkTestGamba.Location = New System.Drawing.Point(37, 388)
        Me.chkTestGamba.Name = "chkTestGamba"
        Me.chkTestGamba.Size = New System.Drawing.Size(108, 21)
        Me.chkTestGamba.TabIndex = 40
        Me.chkTestGamba.Text = "Test Gamba"
        Me.chkTestGamba.UseVisualStyleBackColor = True
        '
        'lblServo
        '
        Me.lblServo.AutoSize = True
        Me.lblServo.Location = New System.Drawing.Point(10, 2)
        Me.lblServo.Name = "lblServo"
        Me.lblServo.Size = New System.Drawing.Size(45, 17)
        Me.lblServo.TabIndex = 41
        Me.lblServo.Text = "Servo"
        '
        'lblAngolo
        '
        Me.lblAngolo.AutoSize = True
        Me.lblAngolo.Location = New System.Drawing.Point(61, 2)
        Me.lblAngolo.Name = "lblAngolo"
        Me.lblAngolo.Size = New System.Drawing.Size(52, 17)
        Me.lblAngolo.TabIndex = 42
        Me.lblAngolo.Text = "Angolo"
        '
        'txtAngoloExt
        '
        Me.txtAngoloExt.Location = New System.Drawing.Point(195, 334)
        Me.txtAngoloExt.Name = "txtAngoloExt"
        Me.txtAngoloExt.Size = New System.Drawing.Size(30, 22)
        Me.txtAngoloExt.TabIndex = 43
        Me.txtAngoloExt.Text = "0"
        '
        'txtTestGamba
        '
        Me.txtTestGamba.Location = New System.Drawing.Point(47, 336)
        Me.txtTestGamba.Name = "txtTestGamba"
        Me.txtTestGamba.Size = New System.Drawing.Size(23, 22)
        Me.txtTestGamba.TabIndex = 45
        Me.txtTestGamba.Text = "0"
        '
        'lstTestServo
        '
        Me.lstTestServo.FormattingEnabled = True
        Me.lstTestServo.ItemHeight = 16
        Me.lstTestServo.Items.AddRange(New Object() {"Femore", "Rotazione"})
        Me.lstTestServo.Location = New System.Drawing.Point(91, 334)
        Me.lstTestServo.Name = "lstTestServo"
        Me.lstTestServo.Size = New System.Drawing.Size(78, 52)
        Me.lstTestServo.TabIndex = 46
        '
        'trkMarcia
        '
        Me.trkMarcia.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.trkMarcia.Location = New System.Drawing.Point(946, 198)
        Me.trkMarcia.Maximum = 5
        Me.trkMarcia.Name = "trkMarcia"
        Me.trkMarcia.Size = New System.Drawing.Size(162, 56)
        Me.trkMarcia.TabIndex = 47
        Me.trkMarcia.Value = 1
        '
        'lblMarcia
        '
        Me.lblMarcia.AutoSize = True
        Me.lblMarcia.Location = New System.Drawing.Point(995, 266)
        Me.lblMarcia.Name = "lblMarcia"
        Me.lblMarcia.Size = New System.Drawing.Size(50, 17)
        Me.lblMarcia.TabIndex = 48
        Me.lblMarcia.Text = "Marcia"
        '
        'chkRetro
        '
        Me.chkRetro.AutoSize = True
        Me.chkRetro.Location = New System.Drawing.Point(951, 290)
        Me.chkRetro.Name = "chkRetro"
        Me.chkRetro.Size = New System.Drawing.Size(69, 21)
        Me.chkRetro.TabIndex = 49
        Me.chkRetro.Text = "Retro "
        Me.chkRetro.UseVisualStyleBackColor = True
        '
        'Timer2
        '
        '
        'txtAngoloInt
        '
        Me.txtAngoloInt.Location = New System.Drawing.Point(195, 357)
        Me.txtAngoloInt.Name = "txtAngoloInt"
        Me.txtAngoloInt.Size = New System.Drawing.Size(30, 22)
        Me.txtAngoloInt.TabIndex = 50
        Me.txtAngoloInt.Text = "0"
        '
        'txtRotazione
        '
        Me.txtRotazione.Location = New System.Drawing.Point(195, 382)
        Me.txtRotazione.Name = "txtRotazione"
        Me.txtRotazione.Size = New System.Drawing.Size(30, 22)
        Me.txtRotazione.TabIndex = 51
        Me.txtRotazione.Text = "0"
        '
        'lblExt
        '
        Me.lblExt.AutoSize = True
        Me.lblExt.Location = New System.Drawing.Point(228, 337)
        Me.lblExt.Name = "lblExt"
        Me.lblExt.Size = New System.Drawing.Size(27, 17)
        Me.lblExt.TabIndex = 52
        Me.lblExt.Text = "Ext"
        '
        'lblInt
        '
        Me.lblInt.AutoSize = True
        Me.lblInt.Location = New System.Drawing.Point(228, 360)
        Me.lblInt.Name = "lblInt"
        Me.lblInt.Size = New System.Drawing.Size(23, 17)
        Me.lblInt.TabIndex = 53
        Me.lblInt.Text = "Int"
        '
        'lblRot
        '
        Me.lblRot.AutoSize = True
        Me.lblRot.Location = New System.Drawing.Point(231, 385)
        Me.lblRot.Name = "lblRot"
        Me.lblRot.Size = New System.Drawing.Size(30, 17)
        Me.lblRot.TabIndex = 54
        Me.lblRot.Text = "Rot"
        '
        'TrkTibiaInt
        '
        Me.TrkTibiaInt.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.TrkTibiaInt.Location = New System.Drawing.Point(946, 323)
        Me.TrkTibiaInt.Maximum = 500
        Me.TrkTibiaInt.Name = "TrkTibiaInt"
        Me.TrkTibiaInt.Size = New System.Drawing.Size(162, 56)
        Me.TrkTibiaInt.TabIndex = 55
        Me.TrkTibiaInt.Value = 260
        '
        'lblTibiaInt
        '
        Me.lblTibiaInt.AutoSize = True
        Me.lblTibiaInt.Location = New System.Drawing.Point(962, 395)
        Me.lblTibiaInt.Name = "lblTibiaInt"
        Me.lblTibiaInt.Size = New System.Drawing.Size(98, 17)
        Me.lblTibiaInt.TabIndex = 56
        Me.lblTibiaInt.Text = "Lungh TibiaInt"
        '
        'txtValExt
        '
        Me.txtValExt.Location = New System.Drawing.Point(261, 336)
        Me.txtValExt.Name = "txtValExt"
        Me.txtValExt.Size = New System.Drawing.Size(42, 22)
        Me.txtValExt.TabIndex = 57
        Me.txtValExt.Text = " "
        '
        'txtValInt
        '
        Me.txtValInt.Location = New System.Drawing.Point(261, 360)
        Me.txtValInt.Name = "txtValInt"
        Me.txtValInt.Size = New System.Drawing.Size(42, 22)
        Me.txtValInt.TabIndex = 58
        Me.txtValInt.Text = " "
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1157, 421)
        Me.Controls.Add(Me.txtValInt)
        Me.Controls.Add(Me.txtValExt)
        Me.Controls.Add(Me.lblTibiaInt)
        Me.Controls.Add(Me.TrkTibiaInt)
        Me.Controls.Add(Me.lblRot)
        Me.Controls.Add(Me.lblInt)
        Me.Controls.Add(Me.lblExt)
        Me.Controls.Add(Me.txtRotazione)
        Me.Controls.Add(Me.txtAngoloInt)
        Me.Controls.Add(Me.chkRetro)
        Me.Controls.Add(Me.lblMarcia)
        Me.Controls.Add(Me.trkMarcia)
        Me.Controls.Add(Me.lstTestServo)
        Me.Controls.Add(Me.txtTestGamba)
        Me.Controls.Add(Me.txtAngoloExt)
        Me.Controls.Add(Me.lblAngolo)
        Me.Controls.Add(Me.lblServo)
        Me.Controls.Add(Me.chkTestGamba)
        Me.Controls.Add(Me.btnAttenti)
        Me.Controls.Add(Me.txtCom)
        Me.Controls.Add(Me.lblCom)
        Me.Controls.Add(Me.txtPeso)
        Me.Controls.Add(Me.lblPeso)
        Me.Controls.Add(Me.txtCoppia)
        Me.Controls.Add(Me.lblCoppia)
        Me.Controls.Add(Me.lblTibia)
        Me.Controls.Add(Me.trktibia)
        Me.Controls.Add(Me.lblCurva)
        Me.Controls.Add(Me.trkCurva)
        Me.Controls.Add(Me.chkForma)
        Me.Controls.Add(Me.btnBaricentro1)
        Me.Controls.Add(Me.txtDiscriminante)
        Me.Controls.Add(Me.txtGamba)
        Me.Controls.Add(Me.lblDiscriminante)
        Me.Controls.Add(Me.lblGamba)
        Me.Controls.Add(Me.lblRitardoAlzo)
        Me.Controls.Add(Me.trkRitardoAlzo)
        Me.Controls.Add(Me.lblTimer)
        Me.Controls.Add(Me.trkTimer)
        Me.Controls.Add(Me.btnBaricentro)
        Me.Controls.Add(Me.btnSopra)
        Me.Controls.Add(Me.btnFianco)
        Me.Controls.Add(Me.lblRapporto)
        Me.Controls.Add(Me.trkFermore)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.lblLarghezza)
        Me.Controls.Add(Me.lblLunghezza)
        Me.Controls.Add(Me.trkLarghezza)
        Me.Controls.Add(Me.trkLunghezza)
        Me.Controls.Add(Me.btnstart)
        Me.Controls.Add(Me.lblSpinta)
        Me.Controls.Add(Me.trkSpinta)
        Me.Controls.Add(Me.lblPasso)
        Me.Controls.Add(Me.lblVelocita)
        Me.Controls.Add(Me.trkPasso)
        Me.Controls.Add(Me.trkVelAlzo)
        Me.Controls.Add(Me.picSopra)
        Me.Controls.Add(Me.picFianco)
        Me.Name = "Form1"
        Me.Text = "Simulatore Camminata "
        CType(Me.picFianco, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picSopra, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkVelAlzo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkPasso, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkSpinta, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkLunghezza, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkLarghezza, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkFermore, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkTimer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkRitardoAlzo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkCurva, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trktibia, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkMarcia, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrkTibiaInt, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents picFianco As PictureBox
    Friend WithEvents picSopra As PictureBox
    Friend WithEvents tmrCamminata As Timer
    Friend WithEvents trkVelAlzo As TrackBar
    Friend WithEvents trkPasso As TrackBar
    Friend WithEvents lblVelocita As Label
    Friend WithEvents lblPasso As Label
    Friend WithEvents trkSpinta As TrackBar
    Friend WithEvents lblSpinta As Label
    Friend WithEvents btnstart As Button
    Friend WithEvents trkLunghezza As TrackBar
    Friend WithEvents trkLarghezza As TrackBar
    Friend WithEvents lblLunghezza As Label
    Friend WithEvents lblLarghezza As Label
    Friend WithEvents btnReset As Button
    Friend WithEvents trkFermore As TrackBar
    Friend WithEvents lblRapporto As Label
    Friend WithEvents btnFianco As Button
    Friend WithEvents btnSopra As Button
    Friend WithEvents btnBaricentro As Button
    Friend WithEvents Timer1 As Timer
    Friend WithEvents trkTimer As TrackBar
    Friend WithEvents lblTimer As Label
    Friend WithEvents trkRitardoAlzo As TrackBar
    Friend WithEvents lblRitardoAlzo As Label
    Friend WithEvents lblGamba As Label
    Friend WithEvents lblDiscriminante As Label
    Friend WithEvents txtGamba As TextBox
    Friend WithEvents txtDiscriminante As TextBox
    Friend WithEvents btnBaricentro1 As Button
    Friend WithEvents chkForma As CheckBox
    Friend WithEvents trkCurva As TrackBar
    Friend WithEvents lblCurva As Label
    Friend WithEvents trktibia As TrackBar
    Friend WithEvents lblTibia As Label
    Friend WithEvents lblCoppia As Label
    Friend WithEvents txtCoppia As TextBox
    Friend WithEvents lblPeso As Label
    Friend WithEvents txtPeso As TextBox
    Friend WithEvents lblCom As Label
    Friend WithEvents txtCom As TextBox
    Friend WithEvents btnAttenti As Button
    Friend WithEvents chkTestGamba As CheckBox
    Friend WithEvents lblServo As Label
    Friend WithEvents lblAngolo As Label
    Friend WithEvents txtAngoloExt As TextBox
    Friend WithEvents txtTestGamba As TextBox
    Friend WithEvents lstTestServo As ListBox
    Friend WithEvents trkMarcia As TrackBar
    Friend WithEvents lblMarcia As Label
    Friend WithEvents chkRetro As CheckBox
    Friend WithEvents Timer2 As Timer
    Friend WithEvents txtAngoloInt As TextBox
    Friend WithEvents txtRotazione As TextBox
    Friend WithEvents lblExt As Label
    Friend WithEvents lblInt As Label
    Friend WithEvents lblRot As Label
    Friend WithEvents TrkTibiaInt As TrackBar
    Friend WithEvents lblTibiaInt As Label
    Friend WithEvents txtValExt As TextBox
    Friend WithEvents txtValInt As TextBox
End Class
