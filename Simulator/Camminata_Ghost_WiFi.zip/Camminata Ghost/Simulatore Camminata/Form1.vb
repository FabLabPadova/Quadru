﻿Imports System.Threading
Imports System.Net
Imports System.Text
Imports System.Net.Sockets
Imports Newtonsoft.Json

Public Class Form1
    Dim angMaxServo As Double = 60, direzMoto As Int16 = 1
    Dim flagIncrocio1, flagIncrocio2 As Boolean
    Dim bCurvaContinua As Boolean = True
    Dim a, b, c, d, e As Double
    Dim xd1, xd2, yd1, yd2, xd3, yd3, xd4, yd4, xd5, yd5 As Double
    Dim diagn1, diagn2, diagn3, diagn4, diagn5, diagn6 As Double
    Dim FemoreX(7), FemoreY(7), TibiaX(7), memTibiaAvanti(7), TibiaY(7), piedeX(7), piedeY(7), discriminante(7) As Double
    Dim angInizFemore, angInizTibia, angFemore(7), angTibia(7), errX(7), errY(7), AltezzaTerra, altezzaTerraInt As Double
    Dim piedeSopraX(7), FemoreSopraX(7), TibiaSopraX(7), FemoreSopraY(7), TibiaSopraY(7), piedeSopraY(7) As Double
    Dim angFinalFemore, angFinalTibia, posxMaxAvanti, posxMaxIndietro, posxMinAvanti, posxMinIndietro, angMaxCurva As Double
    Dim LunghezzaGamba, LunghezzaGambaInt, LunghezzaTibia, valTibia, lunghezzaTibiaInt, LunghezzaFemore, curvatura, lungBacino, largBacino, passoOld, valtibiaOld As Double
    Dim salvaRitardo, valAngZero, shiftAngolo As Integer
    Dim counterSend As Integer = 0
    Dim memAngFemore(7), finalAngFemore(7), memAngTibia(7), memAngRotazione(7) As Double, intervalloDiluizione, contaInvii As Integer, memCi As Integer
    Dim deltaAngFemore(7), deltaAngTibia(7), deltaAngRotazione(7) As Double

    Dim BarX, BarY, raggioTibia(7), raggioFemore(7), angoloCurva(7), faseCurva(7), angRotaz(7) As Double

    Dim telnetPort As Integer = 80
    Dim telnetServerIp As String = "192.168.1.233"
    Dim client As TcpClient




    Dim posizione(7) As String



    Dim bprint, bPrint1, bPrima, bAlzo(7), bGiaAlzato(7) As Boolean

    Dim correzione, constX1, constY1, constK, varX As Double



    Dim constA, constB, constC, sporgGinocchio, velocAvanzamento, lunghPasso, pesoSuGamba As Double
    Dim cicliRitardoAlzo, cicliFatti, candidatoAlzo, candidatoAlzoCurva, contaAlzi, contaAlzati As Integer
    Dim bCandidabile, bPiedeAlzato, bPrimoPasso, bCurva, bAttenti As Boolean
    Dim gambeAlzate As Integer
    Public TPen As New System.Drawing.Pen(System.Drawing.Color.Black, 1)
    Public Fase(7), spess As Integer, color As Color
    Public lavGraphics As System.Drawing.Graphics

    Public Sub Picline(X1 As Long, Y1 As Long, X2 As Long, Y2 As Long)
        TPen.Width = spess
        TPen.Color = Color.Blue
        lavGraphics.DrawLine(TPen, X1, Y1, X2, Y2)

    End Sub
    Public Sub Picline(X1 As Long, Y1 As Long, X2 As Long, Y2 As Long, Colore As Color)

        TPen.Width = spess
        TPen.Color = Colore
        lavGraphics.DrawLine(TPen, X1, Y1, X2, Y2)

    End Sub
    Public Sub PicEllisse(Xcentro As Double, Ycentro As Double, larghezza As Double, altezza As Double)
        Dim Rect As New Rectangle
        Rect.X = Xcentro - larghezza / 2
        Rect.Y = Ycentro - altezza / 2
        Rect.Width = larghezza
        Rect.Height = altezza
        TPen.Width = spess
        'TPen.Color = Color.Blue
        lavGraphics.DrawEllipse(TPen, Rect)
    End Sub
    Private Sub lstTestServo_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstTestServo.SelectedIndexChanged
        ' chkTestGamba_CheckedChanged(sender, e)
    End Sub
    Private Sub txtAngoloServo_TextChanged(sender As Object, e As EventArgs) Handles txtAngoloExt.TextChanged
        ' chkTestGamba_CheckedChanged(sender, e)
    End Sub
    Private Sub txtAngoloInt_TextChanged(sender As Object, e As EventArgs) Handles txtAngoloInt.TextChanged

    End Sub
    Private Sub txtTestGamba_TextChanged(sender As Object, e As EventArgs) Handles txtTestGamba.TextChanged
        'chkTestGamba_CheckedChanged(sender, e)
    End Sub
    Private Sub chkTestGamba_CheckedChanged(sender As Object, e As EventArgs) Handles chkTestGamba.CheckedChanged
        Dim gamba As Integer
        Dim angoloExt, angoloInt, angoloRot As Double
        If chkTestGamba.Checked = True And btnAttenti.Text = "Riposo!" Then
            picFianco.Refresh()
            picSopra.Refresh()
            angoloExt = Val(txtAngoloExt.Text * Math.PI / 180)
            angoloInt = Val(txtAngoloInt.Text * Math.PI / 180)
            For i = 0 To 3
                angFemore(i) = 0
                angFemore(i + 4) = 0
                angRotaz(i) = 0
            Next
            gamba = Val(txtTestGamba.Text)

            Select Case lstTestServo.SelectedItem
                Case "Femore"
                    angFemore(gamba) = -angoloExt
                    angFemore(gamba + 4) = angoloInt
                Case "Rotazione"
                    angRotaz(gamba) = angoloRot
            End Select
            ' AggiornaCoordinate(gamba)
            For i = 0 To 3
                AggiornaCoordinate(i)

            Next
            'salvaRitardo = intervalloDiluizione
            'intervalloDiluizione = 500
            diluisci()
            'InviaDatiRobot()
            ' chkTestGamba.Checked = False
        End If



    End Sub
    Sub AggiornaTestGamba(gamba As Integer)

        'AggiornaCoordinate(gamba)
        ' DisegnaGamba(gamba)
        ' DisegnaGamba(gamba + 4)

    End Sub
    Sub AggiornaCoordinate(g As Integer)
        Dim angoloAsse, angFemoreAsse, angTibiaAsse, distanzaTibiaAsse, distanzaPiedeAsse As Double
        angoloAsse = (angFemore(g) + angFemore(g + 4)) / 2
        angFemoreAsse = (angFemore(g) - angFemore(g + 4)) / 2
        angTibiaAsse = -Math.Asin(Math.Sin(angFemoreAsse) * LunghezzaFemore / LunghezzaTibia)
        distanzaTibiaAsse = LunghezzaFemore * Math.Cos(angFemoreAsse)
        distanzaPiedeAsse = distanzaTibiaAsse + LunghezzaTibia * Math.Cos(angTibiaAsse)
        TibiaX(g) = FemoreX(g) + LunghezzaFemore * Math.Sin(angFemore(g))
        TibiaY(g) = FemoreY(g) + LunghezzaFemore * Math.Cos(angFemore(g))
        TibiaX(g + 4) = FemoreX(g) + LunghezzaFemore * Math.Sin(angFemore(g + 4))
        TibiaY(g + 4) = FemoreY(g) + LunghezzaFemore * Math.Cos(angFemore(g + 4))
        angTibia(g) = angoloAsse + angTibiaAsse
        angTibia(g + 4) = angoloAsse - angTibiaAsse
        piedeX(g) = FemoreX(g) + distanzaPiedeAsse * Math.Sin(angoloAsse)
        piedeY(g) = FemoreY(g) + distanzaPiedeAsse * Math.Cos(angoloAsse)
        piedeX(g + 4) = piedeX(g)
        piedeY(g + 4) = piedeY(g)
        intervalloDiluizione = trkRitardoAlzo.Value
        If intervalloDiluizione > 0 Then



        End If
    End Sub
    Private Sub btnAttenti_Click(sender As Object, e As EventArgs) Handles btnAttenti.Click

        If btnstart.Text = "Start" Then
            If btnAttenti.Text = "Attenti!" Then
                btnAttenti.Text = "Riposo!"
                passoOld = angInizFemore
                For i = 0 To 3
                    angFemore(i) = 0
                    angFemore(i + 4) = 0
                    angRotaz(i) = 0
                    AggiornaCoordinate(i)
                Next
                diluisci()
                ' passoOld = angInizFemore
                'trkPasso.Value = 0
                ' angInizFemore = 0
                ' ResetRobot()

                ' InviaDatiRobot()
                bAttenti = True
            Else
                btnAttenti.Text = "Attenti!"
                angInizFemore = passoOld
                chkTestGamba.Checked = False
                trkPasso.Value = angInizFemore
                ' ResetRobot()
                For i = 0 To 3
                    angFemore(i) = passoOld
                    angFemore(i + 4) = -passoOld
                    angRotaz(i) = 0
                    AggiornaCoordinate(i)
                Next
                diluisci()
                ' InviaDatiRobot()
                bAttenti = False
            End If

        End If


    End Sub
    Private Sub txtPeso_TextChanged(sender As Object, e As EventArgs) Handles txtPeso.TextChanged
        If LunghezzaGamba > 0 Then ResetRobot()
    End Sub
    Private Sub trktimer_Scroll(sender As Object, e As EventArgs) Handles trkTimer.Scroll

        If trkTimer.Value = 0 Then trkTimer.Value = 1
        lblTimer.Text = "Timer ms/tick " & Str(trkTimer.Value)
        aggiornaInvii()
    End Sub



    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        ResetRobot()
        Timer1.Enabled = False
    End Sub
    Private Sub chkForma_CheckedChanged(sender As Object, e As EventArgs) Handles chkForma.CheckedChanged

        If bPrima = True Then ResetRobot()
        bPrima = True
    End Sub
    Private Sub trkLunghezza_Scroll(sender As Object, e As EventArgs) Handles trkLunghezza.Scroll

        btnSopra.Left = btnFianco.Left
        picFianco.Refresh()
        lblLunghezza.Text = "Lung bacino mm " & Str(trkLunghezza.Value)
        ResetRobot()
    End Sub

    Private Sub trkLarghezza_Scroll(sender As Object, e As EventArgs) Handles trkLarghezza.Scroll

        picSopra.Refresh()
        lblLarghezza.Text = "Larg bacino mm " & Str(trkLarghezza.Value)
        ResetRobot()
    End Sub
    Private Sub trkPasso_Scroll(sender As Object, e As EventArgs) Handles trkPasso.Scroll
        lblPasso.Text = "Angolo Femore " & Str(trkPasso.Value)
        angInizFemore = trkPasso.Value * Math.PI / 180
        ResetRobot()
    End Sub
    Private Sub trkVelalzo_Scroll(sender As Object, e As EventArgs) Handles trkVelAlzo.Scroll
        lblVelocita.Text = "Incr.passo mm/tick " & Str(trkVelAlzo.Value)
        ResetRobot()
    End Sub
    Private Sub trkSpinta_Scroll(sender As Object, e As EventArgs) Handles trkSpinta.Scroll
        lblSpinta.Text = "Velocità mm/tick " & Str(trkSpinta.Value)
        ResetRobot()
    End Sub
    Private Sub trkMarcia_Scroll(sender As Object, e As EventArgs) Handles trkMarcia.Scroll
        lblMarcia.Text = "Marcia " & trkMarcia.Value
        Select Case trkMarcia.Value
            '15 11  11    trkVelAlzo=lunghezzaPasso->spostamentoPasso,passo->posMax/posMin avanti/indietro
        '4   3  3    trkSpinta=velocAvanzamento
        '10  7  6     trkPasso =sporgenza ginocchio
            Case = 0
                trkVelAlzo.Value = 0
                trkSpinta.Value = 0
                trkPasso.Value = 30
                direzMoto = -direzMoto
            Case = 1
                trkVelAlzo.Value = 11
                trkSpinta.Value = 1
                trkPasso.Value = 50
            Case = 2
                trkVelAlzo.Value = 12
                trkSpinta.Value = 2
                trkPasso.Value = 60
            Case = 3
                trkVelAlzo.Value = 13
                trkSpinta.Value = 3
                trkPasso.Value = 90
            Case = 4
                trkVelAlzo.Value = 16
                trkSpinta.Value = 4
                trkPasso.Value = 120
            Case = 5
                trkVelAlzo.Value = 18
                trkSpinta.Value = 5
                trkPasso.Value = 150
        End Select
        lblVelocita.Text = "Incr.passo mm/tick" & Str(trkVelAlzo.Value)
        lblSpinta.Text = "Velocità mm/tick " & Str(trkSpinta.Value)
        lblPasso.Text = "Angolo Femore " & Str(trkPasso.Value)
        angInizFemore = trkPasso.Value * Math.PI / 180
        ResetRobot()
    End Sub
    Private Sub trkRapporto_Scroll(sender As Object, e As EventArgs) Handles trkFermore.Scroll
        lblRapporto.Text = "Lungh Femore mm " & Str(trkFermore.Value)
        ResetRobot()
    End Sub
    Private Sub trktibia_Scroll(sender As Object, e As EventArgs) Handles trktibia.Scroll
        lblTibia.Text = "Lungh Tibia mm " & Str(trktibia.Value)
        ResetRobot()
    End Sub
    Private Sub trktibiaint_Scroll(sender As Object, e As EventArgs) Handles Trktibiaint.Scroll
        lblTibiaInt.Text = "L Tib int mm " & Str(TrkTibiaInt.Value)
        ResetRobot()
    End Sub
    Private Sub trkRitardoAlzo_Scroll(sender As Object, e As EventArgs) Handles trkRitardoAlzo.Scroll
        lblRitardoAlzo.Text = "Intervallo disegno ms " & Str(trkRitardoAlzo.Value)
        aggiornaInvii()
        ' ResetRobot()
    End Sub
    Private Sub trkCurva_Scroll(sender As Object, e As EventArgs) Handles trkCurva.Scroll
        curvatura = trkCurva.Value - 180
        lblCurva.Text = "Curva gradi " & Str(curvatura)
        curvatura = curvatura * Math.PI / 180
        If curvatura <> 0 Then

            If btnstart.Text = "Start" Then
                bCurva = True
                PreparaCurvaDaFermo()
            Else
                PreparaCurvaInMovimento()
            End If
        End If
    End Sub
    Private Sub lblCurva_doubleclick(sender As Object, e As EventArgs) Handles lblCurva.DoubleClick
        trkCurva.Value = 180
        curvatura = trkCurva.Value - 180
        lblCurva.Text = "Curva gradi " & Str(curvatura)
        curvatura = curvatura * Math.PI / 180
    End Sub
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        WindowState = FormWindowState.Maximized
        btnSopra.Visible = False
        Left = 0
        Top = 0

        picFianco.Left = 20
        picFianco.Top = 20
        picFianco.Height = Me.Height / 2 - 50
        picFianco.Width = Width / 2
        picSopra.Left = picFianco.Left
        picSopra.Top = picFianco.Top + picFianco.Height + 20
        picSopra.Width = picFianco.Width
        picSopra.Height = picFianco.Height
        btnBaricentro1.Top = picSopra.Top + picSopra.Height / 2
        btnBaricentro1.Left = picSopra.Left + picSopra.Width / 2 + 10
        btnBaricentro1.BackColor = Color.Black
        btnBaricentro.Top = picSopra.Top + picSopra.Height / 2
        btnBaricentro.Left = picSopra.Left + picSopra.Width / 2
        btnBaricentro.BackColor = Color.Black
        btnBaricentro.Focus()
        btnstart.Left = picFianco.Left + picFianco.Width + 30
        btnstart.Top = picFianco.Top
        btnReset.Left = btnstart.Left + btnstart.Width + 20
        btnReset.Top = btnstart.Top
        lblGamba.Top = btnstart.Top + 10
        lblGamba.Left = btnReset.Left + btnReset.Width + 5
        txtGamba.Top = lblGamba.Top
        txtGamba.Left = lblGamba.Left + lblGamba.Width
        lblDiscriminante.Top = lblGamba.Top
        lblDiscriminante.Left = lblGamba.Left + lblGamba.Width + 20
        txtDiscriminante.Top = lblDiscriminante.Top
        txtDiscriminante.Left = lblDiscriminante.Left + lblDiscriminante.Width
        lblCom.Top = txtDiscriminante.Top
        lblCom.Left = lblDiscriminante.Left + lblDiscriminante.Width + 50
        txtCom.Top = lblCom.Top
        txtCom.Left = lblCom.Left + lblCom.Width

        chkForma.Top = lblDiscriminante.Top
        chkForma.Left = txtCom.Left + txtCom.Width + 30
        btnAttenti.Top = chkForma.Top
        btnAttenti.Left = chkForma.Left + chkForma.Width + 30
        trkVelAlzo.Left = btnstart.Left
        trkPasso.Left = trkVelAlzo.Left
        trkSpinta.Left = trkVelAlzo.Left
        trkLunghezza.Left = trkVelAlzo.Left
        trkLarghezza.Left = trkVelAlzo.Left
        trkFermore.Left = trkVelAlzo.Left
        trktibia.Left = trkVelAlzo.Left
        trktibia.Top = trkFermore.Top + trkFermore.Height + 10

        Trktibiaint.Top = trktibia.Top
        trkRitardoAlzo.Left = trkVelAlzo.Left
        trkRitardoAlzo.Top = trktibia.Top + trktibia.Height + 10
        lblRitardoAlzo.Top = trkRitardoAlzo.Top
        lblRitardoAlzo.Left = trkRitardoAlzo.Left + trkRitardoAlzo.Width + 5
        trkTimer.Left = trkVelAlzo.Left
        trkTimer.Top = trkRitardoAlzo.Top + trkRitardoAlzo.Height + 10
        trkCurva.Left = trkTimer.Left
        trkCurva.Top = trkTimer.Top + trkTimer.Height + 10
        lblCurva.Top = trkCurva.Top
        lblCurva.Left = trkCurva.Left + trkCurva.Width + 5
        curvatura = trkCurva.Value - 180
        lblCurva.Text = "Curva gradi " & Str(curvatura)
        lblVelocita.Left = trkVelAlzo.Left + trkVelAlzo.Width + 10
        lblTimer.Top = trkTimer.Top
        lblTimer.Left = trkTimer.Left + trkTimer.Width + 5
        lblPasso.Left = lblVelocita.Left
        lblSpinta.Left = lblVelocita.Left
        lblLunghezza.Left = lblVelocita.Left
        lblLarghezza.Left = lblVelocita.Left
        lblRapporto.Left = lblVelocita.Left
        lblTibia.Left = lblVelocita.Left
        lblTibia.Top = trktibia.Top
        lblCoppia.Top = trkSpinta.Top
        lblCoppia.Left = lblSpinta.Left + lblSpinta.Width + 50
        txtCoppia.Top = lblCoppia.Top
        txtCoppia.Left = lblCoppia.Left + lblCoppia.Width
        lblPeso.Top = lblCoppia.Top
        lblPeso.Left = lblCoppia.Left + lblCoppia.Width + 40
        txtPeso.Top = lblPeso.Top
        txtPeso.Left = lblPeso.Left + lblPeso.Width

        btnFianco.Top = picFianco.Top + 20
        btnFianco.Height = 20

        btnSopra.Left = btnFianco.Left

        LunghezzaGamba = picFianco.Height - (btnFianco.Top + btnFianco.Height - picFianco.Top)
        lblLarghezza.Text = "Larg bacino mm" & Str(trkLarghezza.Value)
        lblLunghezza.Text = "Lung bacino mm " & Str(trkLunghezza.Value)
        lblPasso.Text = "Angolo Femore" & Str(trkPasso.Value)
        angInizFemore = trkPasso.Value * Math.PI / 180
        trkMarcia.Left = lblPasso.Left + 170
        Trktibiaint.Left = trkMarcia.Left
        lblMarcia.Top = trkMarcia.Top
        lblMarcia.Left = trkMarcia.Left + trkMarcia.Width + 10
        lblMarcia.Text = "Marcia " & trkMarcia.Value
        chkRetro.Top = lblMarcia.Top + 30
        chkRetro.Left = lblMarcia.Left
        lblVelocita.Text = "Incr.passo mm/tick" & Str(trkVelAlzo.Value)
        lblSpinta.Text = "Velocità mm/tick " & Str(trkSpinta.Value)
        lblRapporto.Text = "Lungh Femore mm " & Str(trkFermore.Value)
        lblTibia.Text = "Lungh Tibia mm " & Str(trktibia.Value)
        lblTibiaInt.Text = "L Tib int mm " & Str(TrkTibiaInt.Value)
        lblTibiaInt.Top = TrkTibiaInt.Top
        lblTibiaInt.Left = lblMarcia.Left
        lblRitardoAlzo.Text = "Intervallo disegno ms " & Str(trkRitardoAlzo.Value)
        lblTimer.Text = "Timer ms/tick " & Str(trkTimer.Value)
        chkTestGamba.Top = trkLarghezza.Top
        chkTestGamba.Left = lblLarghezza.Left + lblLarghezza.Width + 80
        lblServo.Top = chkTestGamba.Top '+ chkTestGamba.Height + 8
        lblServo.Left = chkTestGamba.Left + 120
        lstTestServo.Top = lblServo.Top + 40
        lstTestServo.Left = chkTestGamba.Left
        lblAngolo.Top = lblServo.Top + lstTestServo.Left + 10
        lblAngolo.Left = lstTestServo.Left + 40
        txtTestGamba.Top = chkTestGamba.Top
        txtTestGamba.Left = chkTestGamba.Left + chkTestGamba.Width + 60

        txtAngoloExt.Top = lstTestServo.Top
        txtAngoloExt.Left = lstTestServo.Left + lstTestServo.Width + 34
        txtAngoloInt.Top = txtAngoloExt.Top
        txtAngoloInt.Left = lstTestServo.Left + lstTestServo.Width + 3
        txtValExt.Top = txtAngoloExt.Top + txtAngoloExt.Height + 2
        txtValExt.Left = txtAngoloExt.Left + 4
        txtValInt.Top = txtAngoloInt.Top + txtAngoloInt.Height + 2
        txtValInt.Left = txtAngoloInt.Left
        txtRotazione.Top = txtValInt.Top + txtValInt.Height + 2
        txtRotazione.Left = txtAngoloInt.Left
        lblExt.Top = txtAngoloExt.Top - 16
        lblExt.Left = txtAngoloExt.Left
        lblInt.Top = lblExt.Top
        lblInt.Left = txtAngoloInt.Left
        lblRot.Top = lblExt.Top + 86
        lblRot.Left = txtRotazione.Left
        posizione(0) = "avanti"
        posizione(1) = "avanti"
        posizione(2) = "dietro"
        posizione(3) = "dietro"
        posizione(4) = "avanti"
        posizione(5) = "avanti"
        posizione(6) = "dietro"
        posizione(7) = "dietro"
        gambeAlzate = 0
        ' btnFianco.Visible = False
        ' spess = 6
        'Picline(picFianco.Top + 20, btnFianco.Top, btnFianco.Left + btnFianco.Width, btnFianco.Top, Color.Goldenrod)
    End Sub
    Private Sub btnstart_Click(sender As Object, e As EventArgs) Handles btnstart.Click
        If btnstart.Text = "Start" Then

            If bAttenti = True Then
                trkPasso.Value = passoOld
                ResetRobot()
                bAttenti = False
            End If
            btnstart.Text = "Stop"
            StartAnimazione()
        Else
            btnstart.Text = "Start"
            client.Close()
            StopAnimazione()
        End If

    End Sub
    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        ResetRobot()

    End Sub
    Sub ResetRobot()
        Dim i As Int16
        picFianco.Refresh()
        picSopra.Refresh()
        flagIncrocio1 = False
        flagIncrocio2 = False

        For i = 0 To 7
            ResetGamba(i)
            DisegnaGamba(i)
        Next


    End Sub
    Function PiuIndietro(r As Short, s As Short, t As Short) As Short
        Dim p(3) As Double
        p(0) = piedeX(0) - FemoreX(0)
        p(1) = piedeX(1) - FemoreX(1)
        p(2) = piedeX(2) - FemoreX(2)
        p(3) = piedeX(3) - FemoreX(3)
        If p(r) <= p(s) And p(r) <= p(t) Then
            PiuIndietro = r
        ElseIf p(t) <= p(r) And p(t) <= p(s) Then
            PiuIndietro = t
        ElseIf p(s) <= p(r) And p(s) <= p(t) Then
            PiuIndietro = s
        End If
        Return PiuIndietro
    End Function
    Function EntroBaricentro(g As Short) As Double
        Dim fuoriBaricentro As Double
        EntroBaricentro = 0
        BarX = picSopra.Left + picSopra.Width / 2

        If posizione(g) = "avanti" Then
            BarX = BarX - 60
        Else
            BarX = BarX + 60
        End If
        btnBaricentro.Left = BarX
        If g = 0 Then
            fuoriBaricentro = BarX - (TibiaX(1) - TibiaX(3)) / 2
            If fuoriBaricentro > 0 Then
                EntroBaricentro = fuoriBaricentro
            End If
        ElseIf g = 1 Then
            fuoriBaricentro = BarX - (TibiaX(0) - TibiaX(2)) / 2
            If fuoriBaricentro > 0 Then
                EntroBaricentro = fuoriBaricentro
            End If
        ElseIf g = 2 Then
            fuoriBaricentro = BarX - (TibiaX(1) - TibiaX(3)) / 2
            If fuoriBaricentro < 0 Then
                EntroBaricentro = fuoriBaricentro
            End If
        ElseIf g = 3 Then
            fuoriBaricentro = BarX - (TibiaX(0) - TibiaX(2)) / 2
            If fuoriBaricentro < 0 Then
                EntroBaricentro = fuoriBaricentro
            End If
        End If

    End Function
    Sub aggiornaInvii()
        Dim g As Int16
        intervalloDiluizione = trkRitardoAlzo.Value
        If intervalloDiluizione > 0 Then
            contaInvii = Math.Round(trkTimer.Value / intervalloDiluizione)
            memCi = contaInvii
            For g = 0 To 7
                memAngFemore(g) = angFemore(g)
                memAngTibia(g) = angTibia(g)
                memAngRotazione(g) = angRotaz(g)
            Next
        End If
    End Sub
    Sub Caviglia(g As Short)
        FemoreX(g) = FemoreX(g - 4)
        FemoreY(g) = FemoreY(g - 4)
        piedeX(g) = TibiaX(g - 4) + lunghezzaTibiaInt * Math.Sin(angTibia(g - 4))
        piedeY(g) = TibiaY(g - 4) + lunghezzaTibiaInt * Math.Cos(angTibia(g - 4))

        a = piedeY(g - 4) - TibiaY(g - 4)
        b = TibiaX(g - 4)
        c = lunghezzaTibiaInt
        d = LunghezzaTibia
        e = LunghezzaGamba
        altezzaTerraInt = piedeY(g) - FemoreY(g)
        a = LunghezzaGambaInt
        TrovaPosizioni(g, altezzaTerraInt, 0)
    End Sub
    Sub Caviglia1(g As Short)
        FemoreX(g) = FemoreX(g - 4)
        FemoreY(g) = FemoreY(g - 4)
        piedeX(g) = TibiaX(g - 4) + (valTibia / valtibiaOld) * (piedeX(g - 4) - TibiaX(g - 4))
        piedeY(g) = TibiaY(g - 4) + (valTibia / valtibiaOld) * (piedeY(g - 4) - TibiaY(g - 4))
        ' altezzaTerraInt = AltezzaTerra + (piedeY(g) - piedeY(g - 4))

        altezzaTerraInt = piedeY(g) - FemoreY(g)
        a = LunghezzaGamba
        TrovaPosizioni(g, altezzaTerraInt, 0)
    End Sub
    Sub ResetGamba(g As Short)
        Dim spostamentoPasso As Double, correzione As Double = 0.6, correzione1 As Double = 1.2

        btnSopra.Visible = False
        If g <= 3 Then
            valTibia = trktibia.Value
            valtibiaOld = valTibia
            LunghezzaTibia = LunghezzaGamba * valTibia / (valtibiaOld + trkFermore.Value)

        Else
            valTibia = TrkTibiaInt.Value
            lunghezzaTibiaInt = LunghezzaGamba * valTibia / (valtibiaOld + trkFermore.Value)

        End If

        LunghezzaFemore = LunghezzaGamba * trkFermore.Value / (valtibiaOld + trkFermore.Value)
        If g > 3 Then LunghezzaGambaInt = LunghezzaFemore + lunghezzaTibiaInt



        ' If g > 3 Then LunghezzaFemore = LunghezzaGamba * trkFermore.Value / (TrkTibiaInt.Value + trkFermore.Value)
        sporgGinocchio = LunghezzaFemore * Math.Sin(angInizFemore)
        ' sporgGinocchio = LunghezzaGamba * trkPasso.Value / (valtibiaold + trkFermore.Value)
        pesoSuGamba = Val(txtPeso.Text) / 3000
        txtCoppia.Text = " " & Str((pesoSuGamba * sporgGinocchio * correzione))
        velocAvanzamento = LunghezzaGamba * trkSpinta.Value / (valtibiaOld + trkFermore.Value)
        lunghPasso = LunghezzaGamba * trkVelAlzo.Value / (valtibiaOld + trkFermore.Value)
        lungBacino = LunghezzaGamba * trkLunghezza.Value / (valtibiaOld + trkFermore.Value)
        largBacino = LunghezzaGamba * trkLarghezza.Value / (valtibiaOld + trkFermore.Value)
        btnFianco.Width = lungBacino
        btnFianco.Left = picFianco.Left + (picFianco.Width - lungBacino) / 2
        ' btnFianco.Left = 0
        btnSopra.Left = btnFianco.Left
        btnSopra.Width = lungBacino
        btnSopra.Height = largBacino
        btnSopra.Top = picSopra.Top + (picSopra.Height - btnSopra.Height) / 2

        If g <= 3 Then
            angInizTibia = Math.Asin(Math.Sin(angInizFemore) * LunghezzaFemore / LunghezzaTibia)


            btnFianco.Top = picFianco.Top + 20 + LunghezzaFemore * (1 - Math.Cos(angInizFemore)) + LunghezzaTibia * (1 - Math.Cos(angInizTibia))
            'btnFianco.Top = btnFianco.Top / 2
            FemoreY(g) = btnFianco.Top + btnFianco.Height - 20
            TibiaY(g) = FemoreY(g) + LunghezzaFemore * Math.Cos(angInizFemore)
            piedeY(g) = TibiaY(g) + LunghezzaTibia * Math.Cos(+angInizTibia)
            ' AltezzaTerra = LunghezzaTibia * Math.Cos(angInizTibia) + LunghezzaFemore * Math.Cos(angInizFemore)
            AltezzaTerra = piedeY(g) - FemoreY(g)
            'Debug.Print("a" & Str(g) & Str(Int(angInizFemore * 180 / Math.PI)) & Str(Math.Cos(angInizFemore)) & Str(Int(angInizTibia * 180 / Math.PI)) & Str(Math.Cos(angInizTibia)) & Str(Int(FemoreY(g))) & Str(Int(TibiaY(g))) & Str(Int(piedeY(g))) & Str(Int(AltezzaTerra)) & Str(Int(piedeX(g) - FemoreX(g))) & Str(Int(LunghezzaTibia)))
        End If

        If posizione(g) = "avanti" Then
            FemoreX(g) = btnFianco.Left + lungBacino - 20
        Else
            FemoreX(g) = btnFianco.Left - 20  ' 229 
        End If
        piedeX(g) = FemoreX(g)

        If g <= 3 Then
            angFemore(g) = -angInizFemore
            angTibia(g) = angInizTibia
            TibiaX(g) = FemoreX(g) + LunghezzaFemore * Math.Sin(angFemore(g))
        Else
            Caviglia(g)
            ' Debug.Print("b" & Str(g) & Str(Int(angFemore(g) * 180 / Math.PI)) & Str(Math.Cos(angFemore(g))) & Str(Int(angTibia(g) * 180 / Math.PI)) & Str(Math.Cos(angTibia(g))) & Str(Int(FemoreY(g))) & Str(Int(TibiaY(g))) & Str(Int(piedeY(g))) & Str(Int(AltezzaTerra)) & Str(Int(piedeX(g) - FemoreX(g))) & Str(Int(lunghezzaTibiaInt)))
        End If



        ' Debug.Print("b" & Str(g) & Str(Int(angFemore(g) * 180 / Math.PI)) & Str(Math.Cos(angFemore(g))) & Str(Int(angTibia(g) * 180 / Math.PI)) & Str(Math.Cos(angTibia(g))) & Str(Int(FemoreY(g))) & Str(Int(TibiaY(g))) & Str(Int(piedeY(g))) & Str(Int(AltezzaTerra)))
        ' TrovaPosizioni(g, AltezzaTerra, 0)
        'Debug.Print("c" & Str(g) & Str(Int(angFemore(g) * 180 / Math.PI)) & Str(Math.Cos(angFemore(g))) & Str(Int(angTibia(g) * 180 / Math.PI)) & Str(Math.Cos(angTibia(g))) & Str(Int(FemoreY(g))) & Str(Int(TibiaY(g))) & Str(Int(piedeY(g))) & Str(Int(AltezzaTerra)))
        If posizione(g) = "avanti" Then
            memTibiaAvanti(g) = TibiaX(g)
            a = TibiaX(g)
        End If

        spostamentoPasso = sporgGinocchio * correzione
        posxMaxAvanti = btnFianco.Left + lungBacino + spostamentoPasso - 20

        'posxMaxAvanti = FemoreX(g) + sporgGinocchio
        posxMaxIndietro = btnFianco.Left + spostamentoPasso - 20
        'posxMaxIndietro = FemoreX(g) + sporgGinocchio
        posxMinAvanti = btnFianco.Left + lungBacino - spostamentoPasso * correzione1 - 20
        posxMinIndietro = btnFianco.Left - spostamentoPasso * correzione1 - 20

        If g = 0 Or g = 3 Then
            piedeSopraY(g) = btnSopra.Top - picSopra.Top
            FemoreSopraY(g) = btnSopra.Top - picSopra.Top
            TibiaSopraY(g) = btnSopra.Top - picSopra.Top
        ElseIf g = 1 Or g = 2 Then
            piedeSopraY(g) = btnSopra.Top - picSopra.Top + largBacino
            FemoreSopraY(g) = btnSopra.Top - picSopra.Top + largBacino
            TibiaSopraY(g) = btnSopra.Top - picSopra.Top + largBacino
        ElseIf g = 4 Or g = 7 Then
            piedeSopraY(g) = btnSopra.Top - picSopra.Top + 20
            FemoreSopraY(g) = btnSopra.Top - picSopra.Top + 20
            TibiaSopraY(g) = btnSopra.Top - picSopra.Top + 20
        ElseIf g = 5 Or g = 6 Then
            piedeSopraY(g) = btnSopra.Top - picSopra.Top + largBacino - 20
            FemoreSopraY(g) = btnSopra.Top - picSopra.Top + largBacino - 20
            TibiaSopraY(g) = btnSopra.Top - picSopra.Top + largBacino - 20

        End If


        For i = 0 To 7
            Fase(i) = 2
        Next
        Fase(3) = 1
        btnBaricentro.Left = picSopra.Left + picSopra.Width / 2 - 30
        'angFemore(g) = angInizFemore
        ' angTibia(g) = angInizTibia
        errX(g) = 0
        errY(g) = 0
        color = Color.Coral
        intervalloDiluizione = trkRitardoAlzo.Value
        If intervalloDiluizione > 0 Then

            contaInvii = Math.Round(trkTimer.Value / intervalloDiluizione)
            memCi = contaInvii
            memAngFemore(g) = angFemore(g)
            memAngTibia(g) = angTibia(g)
            memAngRotazione(g) = angRotaz(g)
        End If
    End Sub
    Sub PreparaCurvaInMovimento()
        For g = 0 To 7
            If posizione(g) = "avanti" Then
                angRotaz(g) = angMaxServo * curvatura / 180
            Else
                angRotaz(g) = -angMaxServo * curvatura / 180
            End If

            If posizione(g) = "avanti" Then
                Svolta(g, angRotaz(g))
            Else
                Svolta(g, -angRotaz(g))
            End If
        Next
    End Sub

    Sub PreparaCurvaDaFermo()
        ResetRobot()
        angMaxCurva = Math.Atan((largBacino / 2 + sporgGinocchio * Math.Sin(angMaxServo * Math.PI / 180)) / (lungBacino / 2)) - Math.Atan((largBacino / 2) / (lungBacino / 2))
        diagn1 = Int(10000 * (Math.Tan(angMaxCurva + Math.Atan((largBacino / 2) / (lungBacino / 2))) * (lungBacino / 2) - largBacino / 2) / sporgGinocchio) / 10000

        For i = 0 To 7
            TrovaPosizioni(i, AltezzaTerra, 0)
            angoloCurva(i) = curvatura
            faseCurva(i) = 1
            Fase(i) = 0
        Next
        candidatoAlzoCurva = 0
            contaAlzi = 0
            StartAnimazione()

    End Sub
    Sub EseguiCurvaDaFermo(g As Short)

        piedeSopraX(g) = piedeX(g)

        If faseCurva(g) = 1 Then
            If bCurvaContinua = True Then
                angRotaz(g) = angMaxServo * curvatura / 180
            Else

                If Math.Abs(angoloCurva(g)) > angMaxCurva Then
                    angRotaz(g) = Math.Asin(Int((1000000 * (Math.Tan(angMaxCurva + Math.Atan((largBacino / 2) / (lungBacino / 2))) * (lungBacino / 2) - largBacino / 2)) / (sporgGinocchio * Math.Sin(angMaxServo * Math.PI / 180))) / 1000000)
                    diagn2 = angRotaz(g) * 180 / Math.PI
                    diagn3 = angMaxCurva * 180 / Math.PI
                    diagn4 = angoloCurva(g) * 180 / Math.PI
                    diagn5 = Math.Sin(angMaxServo * Math.PI / 180)
                    If angoloCurva(g) > 0 Then
                        angoloCurva(g) = angoloCurva(g) - angMaxCurva
                    Else
                        angoloCurva(g) = angoloCurva(g) + angMaxCurva
                        angRotaz(g) = -angRotaz(g)
                    End If
                    diagn4 = angoloCurva(g) * 180 / Math.PI
                Else
                    angRotaz(g) = Math.Asin(Int((10000 * (Math.Tan(angoloCurva(g) + Math.Atan((largBacino / 2) / (lungBacino / 2))) * (lungBacino / 2) - largBacino / 2)) / (sporgGinocchio * Math.Sin(angMaxServo * Math.PI / 180))) / 10000)
                    'angolo = Math.Asin(((Math.Tan(angoloCurva(g) + Math.Atan((largBacino / 2) / (lungBacino / 2))) * (lungBacino / 2) - largBacino / 2)) / sporgGinocchio)
                    diagn1 = angRotaz(g) * 180 / Math.PI
                    diagn2 = angoloCurva(g) * 180 / Math.PI
                    angoloCurva(g) = 0

                End If

                lblCurva.Text = "Curva gradi " & Str(angoloCurva(g) * 180 / Math.PI)
            End If
            If posizione(g) = "avanti" Then
                Svolta(g, angRotaz(g))
            Else
                Svolta(g, -angRotaz(g))
            End If
            faseCurva(g) = 2
        ElseIf faseCurva(g) = 2 Then
            If g = candidatoAlzoCurva Then
                bAlzo(g) = True
                faseCurva(g) = 3
                contaAlzati = contaAlzati + 1
                TrovaPosizioni(g, AltezzaTerra - 20, 0)
                Ritorna(g)
            End If

        ElseIf faseCurva(g) = 3 Then

            TrovaPosizioni(g, AltezzaTerra, 0)
            Ritorna(g)
            If g < 3 Then
                candidatoAlzoCurva = candidatoAlzoCurva + 1
                faseCurva(g) = 4
            Else
                candidatoAlzoCurva = 0
                If contaAlzati >= 4 And g = 3 Then
                    contaAlzati = 0
                    If angoloCurva(g) <> 0 Then
                        For i = 0 To 7
                            faseCurva(i) = 1
                        Next
                    Else
                        bCurva = False
                        trkCurva.Value = 180
                        'trkPasso.Value = sporgGinocchio / 2
                        For i = 0 To 7
                            faseCurva(i) = 0
                            Fase(0) = 1
                            Fase(1) = 2
                            Fase(2) = 2
                            Fase(3) = 2
                            candidatoAlzo = 0
                            If i = 0 Or i = 3 Then
                                TibiaSopraY(i) = btnSopra.Top - picSopra.Top
                            Else
                                TibiaSopraY(i) = btnSopra.Top - picSopra.Top + largBacino
                            End If
                        Next
                    End If
                    a = faseCurva(3)
                End If
            End If



        ElseIf faseCurva(g) = 4 Then




        End If
        If angoloCurva(g) = 0 Then
            StopAnimazione()
            bCurva = False
            ResetRobot()
        End If

    End Sub
    Sub Svolta(g As Short, angolo As Double)


        diagn1 = TibiaSopraY(g)
        If posizione(g) = "avanti" Then
            TibiaX(g) = FemoreX(g) + sporgGinocchio * Math.Cos(angolo)
        Else
            If chkForma.Checked = True Then
                TibiaX(g) = FemoreX(g) + sporgGinocchio * Math.Cos(angolo)
            Else
                TibiaX(g) = FemoreX(g) - sporgGinocchio * Math.Cos(angolo)
            End If
        End If
        If g = 0 Or g = 3 Then
            TibiaSopraY(g) = btnSopra.Top - picSopra.Top + sporgGinocchio * Math.Sin(angolo)
        Else
            TibiaSopraY(g) = btnSopra.Top - picSopra.Top + largBacino + sporgGinocchio * Math.Sin(angolo)
        End If

        diagn2 = TibiaSopraY(g)
        diagn3 = angolo * 180 / Math.PI
    End Sub
    Sub Ritorna(g As Short)
        If posizione(g) = "avanti" Then
            TibiaX(g) = FemoreX(g) + sporgGinocchio
        Else
            If chkForma.Checked = True Then
                TibiaX(g) = FemoreX(g) + sporgGinocchio
            Else
                TibiaX(g) = FemoreX(g) - sporgGinocchio
            End If
        End If

        If g = 0 Or g = 3 Then
            TibiaSopraY(g) = btnSopra.Top - picSopra.Top
        Else
            TibiaSopraY(g) = btnSopra.Top - picSopra.Top + largBacino
        End If
        diagn2 = TibiaSopraY(g)
    End Sub



    Sub AggiornaGamba(g As Short)
        Dim passo As Double
        '15 11  11    trkVelAlzo=lunghezzaPasso->spostamentoPasso,passo->posMax/posMin avanti/indietro
        '4   3  3    trkSpinta=velocAvanzamento
        '10  7  6     trkPasso =anginizfemore
        diagn1 = errX(g)
        btnSopra.Visible = False

        If Int(cicliFatti / 4) >= cicliRitardoAlzo And bCandidabile = True Then
            'cicliRitardoAlzo = trkRitardoAlzo.Value
            If g = candidatoAlzo Then
                diagn1 = EntroBaricentro(g)
                If 1 = 1 Or (posizione(g) = "avanti" And piedeX(g) <= posxMinAvanti) Or (posizione(g) = "dietro" And piedeX(g) <= posxMinIndietro) Then
                    If flagIncrocio1 = False And flagIncrocio2 = False Then
                        Fase(g) = 1
                        cicliFatti = 0
                        bCandidabile = False
                    End If
                End If
            End If
        End If
        cicliFatti = cicliFatti + 1


        If Fase(g) = 1 Then

            If g >= 0 And g <= 3 Then Fase(g + 4) = 1
            bCandidabile = False
            passo = lunghPasso
            If 1 = 1 Or (posizione(g) = "avanti" And piedeX(g) + lunghPasso >= posxMaxAvanti) Or (posizione(g) = "dietro" And piedeX(g) + lunghPasso >= posxMaxIndietro) Then
                If posizione(g) = "avanti" Then
                    passo = posxMaxAvanti - piedeX(g)
                    'passo = memTibiaAvanti(g) - piedeX(g)
                Else
                    passo = posxMaxIndietro - piedeX(g)
                End If

                bCandidabile = True
                If bGiaAlzato(g) = True Then
                    If g <= 3 Then
                        TrovaPosizioni(g, AltezzaTerra, -passo)
                    Else
                        Caviglia(g)
                    End If
                    flagIncrocio2 = True
                    bGiaAlzato(g) = False
                    Fase(g) = 2
                Else
                    If g <= 3 Then
                        TrovaPosizioni(g, AltezzaTerra - 30, -passo)
                    Else
                        Caviglia(g)
                    End If
                    flagIncrocio1 = True
                        bGiaAlzato(g) = True
                    End If
                    'Debug.Print("a " & Str(g) & " " & Str(passo) & " " & Str(bGiaAlzato(g)))
                    Else
                If passo <> 0 Then
                    If g <= 3 Then
                        TrovaPosizioni(g, AltezzaTerra - 30, -passo)
                    Else
                        Caviglia(g)
                    End If
                End If
                    flagIncrocio1 = True
                bGiaAlzato(g) = True
            End If
            If g = 0 Then
                candidatoAlzo = 2 'PiuIndietro(1, 2, 3) '3 '
            ElseIf g = 1 Then
                candidatoAlzo = 3 'PiuIndietro(0, 2, 3) '2 '
            ElseIf g = 2 Then
                candidatoAlzo = 1 'PiuIndietro(0, 1, 3) '0 '
            ElseIf g = 3 Then
                candidatoAlzo = 0 'PiuIndietro(0, 1, 2) '1 '
            End If

            If g = 4 Then
                a = 0
            End If


        ElseIf Fase(g) = 2 Then
            If g <= 3 Then
                TrovaPosizioni(g, AltezzaTerra, velocAvanzamento)
            Else
                Caviglia(g)
            End If
        End If
        If piedeX(g) <> 0 Then piedeSopraX(g) = piedeX(g)
    End Sub
    Sub TrovaPosizioni(g As Short, altezzaTerra As Double, spinta As Double)

        'x^2+y^2=R^2
        '(x-x1)^2+(y-y1)^2=R1^2
        'con x1=distanza(piedeX-FemoreX), y1=altezzaterra, R= lunghezzaFemore, R1=lunghezzaTibia
        'x=(-b+-V(b^2-4ac))/2a
        'con x=coord x della tibia
        piedeX(g) = piedeX(g) - spinta
        constX1 = piedeX(g) - FemoreX(g)
        constY1 = altezzaTerra
        If g <= 3 Then
            constK = (LunghezzaFemore ^ 2 - LunghezzaTibia ^ 2 + constX1 ^ 2 + constY1 ^ 2) / (2 * constY1)
        Else
            constK = (LunghezzaFemore ^ 2 - lunghezzaTibiaInt ^ 2 + constX1 ^ 2 + constY1 ^ 2) / (2 * constY1)
        End If
        constA = 1 + (constX1 / constY1) ^ 2
        constB = -2 * constK * constX1 / constY1
        constC = constK ^ 2 - LunghezzaFemore ^ 2
        discriminante(g) = (constB ^ 2 - 4 * constA * constC)
        If Math.Abs(discriminante(g)) < 0.0000000001 Then
            discriminante(g) = 0
        End If

        If discriminante(g) < 0 Then
            txtGamba.Text = Str(g)
            txtDiscriminante.Text = Str(Int(discriminante(g)))
            Application.DoEvents()
            StopAnimazione()
            Exit Sub
        End If
        'If posizione(g) = "avanti" Or chkForma.Checked = True Then
        If g <= 3 Then
            varX = ((-constB - Math.Sqrt(discriminante(g))) / (2 * constA))
        Else
            varX = ((-constB + Math.Sqrt(discriminante(g))) / (2 * constA))
        End If
        TibiaX(g) = varX + FemoreX(g)

        TibiaY(g) = constK - (constX1 / constY1) * varX + FemoreY(g)
        xd2 = TibiaX(g)
        yd2 = TibiaY(g)
        If errX(g) = 0 Then
            errX(g) = xd1 - xd2
            errY(g) = yd1 - yd2
        End If
        angFemore(g) = Math.Asin((TibiaX(g) - FemoreX(g)) / LunghezzaFemore)
        If chkTestGamba.Checked = True And btnAttenti.Text = "Riposo!" And (g = Val(txtTestGamba.Text) Or g = Val(txtTestGamba.Text) + 4) Then
            If g <= 3 Then
                angFemore(g) = Val(txtAngoloExt.Text * Math.PI / 180)
            Else
                angFemore(g) = Val(txtAngoloInt.Text * Math.PI / 180)
            End If
            TibiaX(g) = FemoreX(g) + LunghezzaFemore * Math.Sin(angFemore(g))
            TibiaY(g) = FemoreY(g) + LunghezzaFemore * Math.Cos(angFemore(g))
        End If
        If g <= 3 Then
            angTibia(g) = Math.Asin((piedeX(g) - TibiaX(g)) / LunghezzaTibia)
            piedeY(g) = TibiaY(g) + LunghezzaTibia * Math.Cos(angTibia(g))
        Else
            angTibia(g) = Math.Asin((piedeX(g) - TibiaX(g)) / lunghezzaTibiaInt)
            piedeY(g) = TibiaY(g) + lunghezzaTibiaInt * Math.Cos(angTibia(g))
        End If
        ' Debug.Print("d" & Str(g) & Str(Int(angFemore(g) * 180 / Math.PI)) & Str(Math.Cos(angFemore(g))) & Str(Int(angTibia(g) * 180 / Math.PI)) & Str(Math.Cos(angTibia(g))) & Str(Int(FemoreY(g))) & Str(Int(FemoreX(g))) & Str(Int(TibiaY(g))) & Str(Int(TibiaX(g))) & Str(Int(piedeY(g))) & Str(Int(altezzaTerra)))
        'TibiaX(g) = FemoreX(g) + LunghezzaFemore * Math.Sin(angFemore(g))
        ' TibiaY(g) = FemoreY(g) + LunghezzaFemore * Math.Cos(angFemore(g))
        ' piedeX(g) = TibiaX(g) + LunghezzaTibia * Math.Sin(angTibia(g))
        ' piedeY(g) = TibiaY(g) + LunghezzaTibia * Math.Cos(angTibia(g)) - 4
        'Debug.Print("e" & Str(g) & Str(Int(angFemore(g) * 180 / Math.PI)) & Str(Math.Cos(angFemore(g))) & Str(Int(angTibia(g) * 180 / Math.PI)) & Str(Math.Cos(angTibia(g))) & Str(Int(FemoreY(g))) & Str(Int(FemoreX(g))) & Str(Int(TibiaY(g))) & Str(Int(TibiaX(g))) & Str(Int(piedeY(g))) & Str(Int(altezzaTerra)))
        ' Debug.Print("f" & Str(g) & Str(Int(constA)) & Str(Int(constB)) & Str(Int(constC)) & Str(Int(constK)) & Str(Int(spinta)) & Str(Int(constX1)) & Str(Int(constY1)) & Str(Int(discriminante(g))) & Str(Int(varX)))
    End Sub
    Function cooX(g)
        Dim ang1, xc As Double
        ang1 = Math.PI / 2 - (angFemore(g) + angTibia(g))
        xc = Convert.ToSingle(piedeX(g) + LunghezzaGamba * Math.Cos(ang1) - LunghezzaGamba)
        cooX = xc
    End Function
    Function cooY(g)
        Dim ang1, yc As Double
        ang1 = Math.PI / 2 - (angFemore(g) + angTibia(g))
        yc = Convert.ToSingle(piedeY(g) - LunghezzaGamba * Math.Sin(ang1) + LunghezzaGamba)
        cooY = yc - 2 * LunghezzaGamba
    End Function

    Sub DisegnaGamba(g As Short)

        Dim tibX As Double = TibiaX(g) * Math.Cos(angRotaz(g))
        ' Dim tibX As Double = FemoreX(g) + LunghezzaFemore * Math.Sin(direzMoto * angFemore(g)) * Math.Cos(angRotaz(g))
        Dim piedX = piedeX(g) * Math.Cos(angRotaz(g))
        'Dim piedX = tibX + LunghezzaTibia * Math.Sin(direzMoto * angTibia(g)) * Math.Cos(angRotaz(g))
        'Dim piedX =
        Dim tibSopraY As Double = FemoreSopraY(g) + LunghezzaFemore * Math.Sin(direzMoto * angFemore(g)) * Math.Sin(angRotaz(g))
        Dim piedSopraY As Double = tibSopraY + LunghezzaTibia * Math.Sin(direzMoto * angTibia(g)) * Math.Sin(angRotaz(g))
        piedeSopraX(g) = piedX
        TibiaSopraX(g) = tibX
        Dim lTib As Double
        lTib = Math.Sqrt((piedX - tibX) ^ 2 + (piedeY(g) - TibiaY(g)) ^ 2)
        bprint = True
        bPrint1 = True
        diagn6 = diagn6 + 1
        'If g <> 0 Then Exit Sub
        lavGraphics = picFianco.CreateGraphics
        spess = 1
        TPen.Color = Color.Black
        PicEllisse(FemoreX(g), FemoreY(g), 2 * LunghezzaFemore, 2 * LunghezzaFemore)

        PicEllisse(piedX, piedeY(g), 2 * lTib, 2 * lTib)
        ' PicEllisse(piedX, piedeY(g), 2 * LunghezzaTibia, 2 * LunghezzaTibia)
        spess = 4
        If g = 0 Or g = 3 Then
            color = Color.Bisque
        ElseIf g = 1 Or g = 2 Then
            color = Color.Coral
        ElseIf g = 4 Or g = 7 Then
            color = Color.BlueViolet
        ElseIf g = 5 Or g = 6 Then
            color = Color.ForestGreen
        End If
        Picline(FemoreX(g), FemoreY(g), tibX, TibiaY(g), color)
        Picline(tibX, TibiaY(g), piedX, piedeY(g), color)

        TPen.Color = Color.Red
        PicEllisse(FemoreX(g), FemoreY(g), 5, 5)
        PicEllisse(tibX, TibiaY(g), 5, 5)
        TPen.Color = Color.Blue
        PicEllisse(piedX, piedeY(g), 5, 5)

        lavGraphics = picSopra.CreateGraphics
        spess = 2
        color = Color.Red
        Picline(btnSopra.Left - picSopra.Left, btnSopra.Top - picSopra.Top, btnSopra.Left + btnSopra.Width - picSopra.Left, btnSopra.Top - picSopra.Top, color)
        Picline(btnSopra.Left - picSopra.Left, btnSopra.Top + largBacino - picSopra.Top, btnSopra.Left + btnSopra.Width - picSopra.Left, btnSopra.Top - picSopra.Top + largBacino, color)
        Picline(btnSopra.Left - picSopra.Left, btnSopra.Top - picSopra.Top, btnSopra.Left - picSopra.Left, btnSopra.Top + largBacino - picSopra.Top, color)
        Picline(btnSopra.Left + btnSopra.Width - picSopra.Left, btnSopra.Top - picSopra.Top, btnSopra.Left + btnSopra.Width - picSopra.Left, btnSopra.Top + largBacino - picSopra.Top, color)

        spess = 4
        TPen.Color = Color.Blue
        PicEllisse(piedX, piedSopraY, 5, 5)
        spess = 3
        TPen.Color = Color.Green
        PicEllisse(FemoreX(g), FemoreSopraY(g), 3, 3)
        TPen.Color = Color.Red
        PicEllisse(tibX, tibSopraY, 3, 3)
        spess = 2
        color = Color.Yellow
        Picline(FemoreX(g), FemoreSopraY(g), tibX, tibSopraY, color)
        color = Color.Azure
        Picline(tibX, tibSopraY, piedX, piedSopraY, color)
        color = Color.Black
        spess = 1
        bprint = True
        For i = 0 To 7
            If piedeSopraX(i) = 0 Or piedeSopraY(i) = 0 Then
                bprint = False
            End If
        Next

        If bAlzo(g) = True Then
            'bAlzo(g) = False
            ' If g = 0 Then
            ' candidatoAlzoCurva = 1
            'ElseIf g = 1 Then
            ' candidatoAlzoCurva = 2
            'ElseIf g = 2 Then
            '  candidatoAlzoCurva = 3
            'ElseIf g = 3 Then
            '   candidatoAlzoCurva = 0
            'End If
        End If

        If bPiedeAlzato = True Then


        End If

    End Sub

    Sub StopAnimazione()
        tmrCamminata.Enabled = False
        Timer2.Enabled = False
    End Sub
    Sub StartAnimazione()

        tmrCamminata.Interval = trkTimer.Value + 10 * memCi
        tmrCamminata.Enabled = True
    End Sub

    Private Sub tmrCamminata_Tick(sender As Object, e As EventArgs) Handles tmrCamminata.Tick
        Dim i As Int16


        If bCurva = False Then
            For i = 0 To 7
                AggiornaGamba(i)
                txtGamba.Text = Str(i)
                txtDiscriminante.Text = Str(Int(discriminante(i)))
            Next
        Else
            If btnstart.Text = "Start" Then
                For i = 0 To 7
                    EseguiCurvaDaFermo(i)
                Next
            End If
        End If
        'Application.DoEvents()
        ' Dim stopwatch As Stopwatch = Stopwatch.StartNew
        ' Thread.Sleep(1)
        'Stopwatch.Stop()
        bPiedeAlzato = False
        If flagIncrocio1 = True And flagIncrocio2 = True Then
            flagIncrocio1 = False
            flagIncrocio2 = False
        End If
        For i = 0 To 7

            If Fase(i) = 1 Then
                bPiedeAlzato = True

            End If

            diagn1 = faseCurva(2)
        Next
        diluisci()



    End Sub
    Sub diluisci()
        If intervalloDiluizione > 0 Then
            contaInvii = Math.Round(trkTimer.Value / intervalloDiluizione)
            If contaInvii > 0 Then
                For i = 0 To 7
                    finalAngFemore(i) = angFemore(i)
                Next
                For i = 0 To 7
                    deltaAngFemore(i) = (angFemore(i) - memAngFemore(i)) / contaInvii
                    deltaAngTibia(i) = (angTibia(i) - memAngTibia(i)) / contaInvii
                    deltaAngRotazione(i) = (angRotaz(i) - memAngRotazione(i)) / contaInvii
                Next
                Timer2.Interval = Math.Round(tmrCamminata.Interval / contaInvii)
                Timer2.Enabled = True
            End If
        Else
            picFianco.Refresh()
            picSopra.Refresh()
            For i = 0 To 7
                If discriminante(i) >= 0 Then
                    DisegnaGamba(i)
                Else
                    txtGamba.Text = Str(i)
                    txtDiscriminante.Text = Str(Int(discriminante(i)))
                    Application.DoEvents()
                    StopAnimazione()
                    Exit Sub
                End If

            Next i
            InviaDatiRobot()
        End If

    End Sub
    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        Application.DoEvents()
        If contaInvii > 0 Then
            picFianco.Refresh()
            picSopra.Refresh()
            For i = 0 To 3
                angFemore(i) = memAngFemore(i) + deltaAngFemore(i)
                angTibia(i) = memAngTibia(i) + deltaAngTibia(i)
                angRotaz(i) = memAngRotazione(i) + deltaAngRotazione(i)
                TibiaX(i) = FemoreX(i) + LunghezzaFemore * Math.Sin(angFemore(i))
                piedeX(i) = TibiaX(i) + LunghezzaTibia * Math.Sin(angTibia(i))
                memAngFemore(i) = angFemore(i)
                memAngTibia(i) = angTibia(i)
                memAngRotazione(i) = angRotaz(i)
                If discriminante(i) >= 0 Then
                    DisegnaGamba(i)
                Else
                    txtGamba.Text = Str(i)
                    txtDiscriminante.Text = Str(Int(discriminante(i)))
                    Application.DoEvents()
                    StopAnimazione()
                    Exit Sub
                End If


            Next
            For i = 4 To 7
                Caviglia(i)
                DisegnaGamba(i)
            Next
            InviaDatiRobot()
            contaInvii -= 1

        Else
            Timer2.Enabled = False
        End If

    End Sub

    Sub InviaDatiRobot()
        Dim ghost As New DataGhost()
        ghost.NPack = 0
        If contaInvii = 0 Then
            contaInvii = 1
            memCi = contaInvii
        End If
        Dim datiAngoli As String = Trim(Str(counterSend)) & ":" & Str(Math.Round(trkTimer.Value / memCi))
        Dim datiInChiaro As String = Trim(Str(counterSend)) & ":" & Str(Math.Round(trkTimer.Value / memCi))
        Dim dati As String = Trim(Str(counterSend)) & ":" & Replace(Hex(Math.Round(trkTimer.Value / memCi)).PadLeft(3), " ", "0")


        For i = 0 To 3
            ghost.GhostSingleLeg(i) = New GhostSingleLeg
            If i = 1 Or i = 2 Then
                valAngZero = 2200
                direzMoto = -1
                shiftAngolo = 0
            Else
                valAngZero = 800
                direzMoto = 1
                shiftAngolo = -0
            End If

            For j = 0 To 2
                ghost.GhostSingleLeg(i).GhostSinglePart(j) = New GhostSinglePart
            Next
            'If (chkTestGamba.Checked = True And i <> Val(txtTestGamba.Text)) Or btnstart.Text = "Stop" Then
            ghost.GhostSingleLeg(i).GhostSinglePart(0).Value = Math.Round((direzMoto * -angFemore(i) * (180 / Math.PI) + shiftAngolo) * 1400 / 180) + valAngZero
            ghost.GhostSingleLeg(i).GhostSinglePart(0).Part = "Femore"

            ghost.GhostSingleLeg(i).GhostSinglePart(1).Value = Math.Round((direzMoto * angFemore(i + 4) * (180 / Math.PI) + shiftAngolo) * 1400 / 180) + valAngZero
            ghost.GhostSingleLeg(i).GhostSinglePart(1).Part = "Tibia"

            ghost.GhostSingleLeg(i).GhostSinglePart(2).Value = Math.Round(((angRotaz(i) * (180 / Math.PI))) * 1400 / 180) + 800
            ghost.GhostSingleLeg(i).GhostSinglePart(2).Part = "Rotazione"


            dati &= cmServo(direzMoto * -angFemore(i)) & cmServo(direzMoto * angFemore(i + 4)) & cmServo(angRotaz(i))
            datiInChiaro &= Str(Math.Round((direzMoto * -angFemore(i) * (180 / Math.PI) + shiftAngolo) * 1400 / 180) + valAngZero) & Str(Math.Round((direzMoto * angFemore(i + 4) * (180 / Math.PI) + shiftAngolo) * 1400 / 180) + valAngZero) & Str(Math.Round(((angRotaz(i) * (180 / Math.PI))) * 1400 / 180) + 800)
            datiAngoli &= Str(Math.Round(direzMoto * angFemore(i) * (180 / Math.PI), 1)) & Str(Math.Round((direzMoto * angFemore(i + 4)) * (180 / Math.PI), 1)) & Str(Math.Round(angRotaz(i) * (180 / Math.PI), 1))
        Next

        If chkTestGamba.Checked = True And btnAttenti.Text = "Riposo!" Then
            shiftAngolo = 0
            If Val(txtTestGamba.Text) = 1 Or Val(txtTestGamba.Text) = 2 Then
                valAngZero = 2200
                direzMoto = -1
                shiftAngolo = 0
            Else
                valAngZero = 800
                direzMoto = 1
                shiftAngolo = -0
            End If

            txtValExt.Text = Str(Math.Round((direzMoto * -angFemore(Val(txtTestGamba.Text)) * (180 / Math.PI) + shiftAngolo) * 1400 / 180) + valAngZero)
            txtValInt.Text = Str(Math.Round((direzMoto * angFemore(Val(txtTestGamba.Text) + 4) * (180 / Math.PI) + shiftAngolo) * 1400 / 180) + valAngZero)
            chkTestGamba.Checked = False

        End If
        'txtValExt.Text = Str(Math.Round(((direzMoto * angFemore(Val(txtTestGamba.Text)) * (180 / Math.PI))) * 1400 / 180) + 800)
        dati &= "!"
        ''SendSerialData(dati)
        SendSerialData(ghost)
        ''Debug.Print(dati)
        ''Debug.Print(datiInChiaro)
        ''Debug.Print(datiAngoli)

    End Sub
    Sub SendSerialData(ByVal data As String)

        ' Send strings to a serial port.
        Using com1 As IO.Ports.SerialPort =
            My.Computer.Ports.OpenSerialPort("COM" & txtCom.Text, 9600, System.IO.Ports.Parity.None, 8, 1)
            com1.Write(data)
            If counterSend = 4 Then
                counterSend = 0
            Else
                counterSend = counterSend + 1
            End If
            com1.Close()
        End Using
    End Sub

    Sub SendSerialData(ByRef data As DataGhost)
        Dim reqString As String = Newtonsoft.Json.JsonConvert.SerializeObject(data, Newtonsoft.Json.Formatting.None) + "$"
        Dim enc As Encoding = Encoding.UTF8
        If client Is Nothing OrElse Not client.Connected Then
            client = New TcpClient(telnetServerIp, telnetPort)
        End If
        Try
                ''Qua bisognera' inserire il corretto indirizzo
                Dim dataBytes As [Byte]() = System.Text.Encoding.ASCII.GetBytes(reqString)

                Dim stream As NetworkStream = client.GetStream()
                stream.Write(dataBytes, 0, dataBytes.Length)
            Catch ex As Exception
                Debug.Print("Indirizzo non raggiungibile.")
            End Try
        Debug.Print(reqString)

    End Sub

    Public Function cmServo(ByVal angle As Double) As String
        ' Return Hex(Math.Round(((angle * (180 / Math.PI)) + 90) * 1400 / 180) + 800)
        Return Hex(Math.Round(((angle * (180 / Math.PI)) + shiftAngolo) * 1400 / 180) + valAngZero)
    End Function

    Public Function cmServo1(ByVal angle As Double) As String
        Return Hex(Math.Round(((angle * 180 / Math.PI) * 1400 / 180) + 800))
    End Function


    Public Class DataGhost
        Public NPack As Integer
        Public GhostSingleLeg(3) As GhostSingleLeg
    End Class

    Public Class GhostSingleLeg
        Public GhostSinglePart(2) As GhostSinglePart
    End Class

    Public Class GhostSinglePart
        Public Part As String
        Public Value As Integer

    End Class

End Class

